// helloWorld.cpp

// CSCI 1300 Fall 2022
// Author: Anderson Greer
// Recitation: 101 – Morgan Byers
// Homework 2 - Problem 1

#include <iostream>

using namespace std;

int main() {
    cout << "Hello, World!" << endl; // Prints to console
    return 0; // Ends program
}